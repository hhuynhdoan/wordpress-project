<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'fonicweb_fashion');

/** MySQL database username */
define('DB_USER', 'fonicweb_fashion');

/** MySQL database password */
define('DB_PASSWORD', '2PlT174F');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Q%H ]<{oPoN{gAF/6;IKj4 a%X@qiATSalx8eP9i:^;mt([im0U]/`Rw(g_iI!2A');
define('SECURE_AUTH_KEY',  '*Lgljps/Fl`7[Vn([;l@@;.I5#+-2BSu4f&rOFh{Pc$_X]%TJtc,ZOjq=6LRm=)a');
define('LOGGED_IN_KEY',    ')<xTlX+f=,?oEqQ1:VA:Dh)hAmuFlu30pV]kwxSv{lP?,lTEY-]vhkwWOl|#cQ=c');
define('NONCE_KEY',        'U6|807`WdqJBE^#8yBik/&Cu.c Rc!+4o-E%{jRc:9g{o5 BB],yoo>A8}]rAH?1');
define('AUTH_SALT',        'sOZy/EG=*>r$U%:A?a?_`6NZ/w]0`G1Lp-pUj]Rl`&RHXm-Bj3!SVT8fa:0^W=0f');
define('SECURE_AUTH_SALT', '[1Uci]Z:(=T[ntn}ww=i5z>SiCpwyOmA+A3:dp@A78j-ObT.eFAV?t_$ +O)Q^85');
define('LOGGED_IN_SALT',   'BLgpt|dN4-}aKno~Th+/`^ -`*q.2Y-yiV~#E_Z,.1::f(MB.uu%2;n;lIN4Y~p7');
define('NONCE_SALT',       'V@@6k8KUro`q48AT3i13UWcah!^Z&tUAj<7G6}]>5Id) C>,)%Q-EhRW5}mty=X@');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
